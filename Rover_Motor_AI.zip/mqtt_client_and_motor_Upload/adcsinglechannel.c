/*
 *
 * MODIFIED FROM:
 * adcsinglechannel.c
 *
 *  Created on: Feb 5, 2020
 *  Author: richa
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <unistd.h>
#include <strings.h>
#include <stdio.h>
#include<stdlib.h>
/* POSIX Header files */
#include <pthread.h>

#include <unistd.h>


/* Driver Header files */
#include <ti/drivers/ADC.h>
#include <ti/drivers/UART.h>
#include <ti/drivers/Timer.h>
#include <ti/drivers/GPIO.h>


#include "ti_drivers_config.h"
#include "Timer.h"
#include "Motor_Control.h"
#include "Msg_Queue.h"
#include "Motor_CalcPower.h"
#include "SPI_Handle.h"
#include "debug.h"
#include "FreeRTOS.h"
#include "task.h"

// include all of our header files


/* ADC sample count */
//define ADC_SAMPLE_COUNT  (10)

//#define THREADSTACKSIZE   (1800)


/*
 *  ======== mainThread ========
 */

/*
void *motorControl(void *arg0){
    msg msg_Command;

    uint8_t baudset = 0xAA;
    UART_write(uart, &baudset, sizeof(baudset));

    while(1)
    {
        msg_Command = readFromCommandQueue();
        if(msg_Command.here){
            Set_Motors(msg_Command.data);
        }
    }
}

void *motorUpdateSpeeds (void *arg0){
    msg msg_Encoder;

    dbgUARTStr("START: ");

    while(1)
    {
        msg_Encoder = readFromEncoderQueue();//SPI
        if(msg_Encoder.here){
            update_Motors(msg_Encoder.data);
        }
        else{
            setGoals_PID(msg_Encoder.data[0],msg_Encoder.data[1],msg_Encoder.data[2]);
        }
    }
}


void *testInput (void *arg0){


    msg msg_Input;

    char input[1];
    char inputPast[1];

    int motorSel;
    char inHold[] = "";
    int speed;
    int goals[3] = {0,0,0};

    while(1)
    {
        UART_read(uart_Debug, input, 1);

        if(inputPast[0] == 'M'){
            motorSel = atoi(input);
        }
        else if(input[0] == '='){
            sprintf(inHold, "");
        }
        else if(input[0] == '.'){
            speed = atoi(inHold);
            goals[motorSel-1] = speed;

            msg_Input.data[0] = goals[0];
            msg_Input.data[1] = goals[1];
            msg_Input.data[2] = goals[2];

            msg_Input.here = false;

            sendToEncoderQueue(msg_Input);

        }
        else if(input[0] == 'e'){
            sprintf(inHold, "");
            motorSel = 0;
            input[0] = '0';
            inputPast[0] = '0';

        }
        else if(input[0] == 'r'){
            sprintf(inHold, "");
            motorSel = 0;
            input[0] = '0';
            inputPast[0] = '0';
            goals[0] = 0;
            goals[1] = 0;
            goals[2] = 0;

            msg_Input.data[0] = goals[0];
            msg_Input.data[1] = goals[1];
            msg_Input.data[2] = goals[2];

            msg_Input.here = false;

            sendToEncoderQueue(msg_Input);

        }
        else{
            strncat(inHold, input, sizeof(input));
        }
        inputPast[0] = input[0];
    }
}





void *mainThread(void *arg0)
{
    MQ_init();

    Timer_init();
    UART_init();
    GPIO_init();

    Init_ReadTimer();
    Init_Encoder();


    Init_Motor();
    Init_Debug();
    Init_PID();


    pthread_t           thread0, thread1, thread2;
    pthread_attr_t      attrs;
    struct sched_param  priParam;
    int                 retc;
    int                 detachState;


     Create application threads
    pthread_attr_init(&attrs);

    detachState = PTHREAD_CREATE_DETACHED;
     Set priority and stack size attributes
    retc = pthread_attr_setdetachstate(&attrs, detachState);
    if (retc != 0) {
         pthread_attr_setdetachstate() failed
        while (1);
    }

    retc |= pthread_attr_setstacksize(&attrs, THREADSTACKSIZE);
    if (retc != 0) {
         pthread_attr_setstacksize() failed
        while (1);
    }

     Create threadFxn0 thread
    priParam.sched_priority = 1;
    pthread_attr_setschedparam(&attrs, &priParam);

    retc = pthread_create(&thread0, &attrs, motorUpdateSpeeds, NULL);
    if (retc != 0) {
         pthread_create() failed
        while (1);
    }

     Create threadFxn1 thread
    retc = pthread_create(&thread1, &attrs, motorControl, NULL);
    if (retc != 0) {
         pthread_create() failed
        while (1);
    }

     Create threadFxn1 thread
    retc = pthread_create(&thread2, &attrs, testInput, NULL);
    if (retc != 0) {
         pthread_create() failed
        while (1);
    }
    return (NULL);

}
*/
