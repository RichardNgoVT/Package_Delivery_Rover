/*
 * Motor_Control.h
 *
 *  Created on: Feb 21, 2020
 *      Author: richa
 */

#ifndef EMBEDDED_SYSTEMS_MOTOR_CONTROL_H_
#define EMBEDDED_SYSTEMS_MOTOR_CONTROL_H_


#include <ti/drivers/GPIO.h>
#include <ti/drivers/UART.h>
#include "ti_drivers_config.h"
#include "Timer.h"
#include "debug.h"

UART_Handle uart;




void Init_Motor();
void Set_Motors(int32_t power[]);
void Drive_Motor(uint8_t motor, uint8_t direction, int8_t speed);


#endif /* EMBEDDED_SYSTEMS_MOTOR_CONTROL_H_ */
