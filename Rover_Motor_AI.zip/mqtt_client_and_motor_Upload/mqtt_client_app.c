/*
 * Copyright (c) 2016, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*****************************************************************************

   Application Name     -   MQTT Client
   Application Overview -   The device is running a MQTT client which is
                           connected to the online broker. Three LEDs on the
                           device can be controlled from a web client by
                           publishing msg on appropriate topics. Similarly,
                           message can be published on pre-configured topics
                           by pressing the switch buttons on the device.

   Application Details  - Refer to 'MQTT Client' README.html

*****************************************************************************/
//*****************************************************************************
//
//! \addtogroup mqtt_server
//! @{
//
//*****************************************************************************
/* Standard includes                                                         */
#include <stdlib.h>
#include <pthread.h>
#include <mqueue.h>
#include <time.h>
#include <unistd.h>
#include<stdio.h>
/* TI-Driver includes                                                        */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/SPI.h>
#include <ti/drivers/Timer.h>
/* Simplelink includes                                                       */
#include <ti/drivers/net/wifi/simplelink.h>

/* SlNetSock includes                                                        */
#include <ti/drivers/net/wifi/slnetifwifi.h>

/* MQTT Library includes                                                     */
#include <ti/net/mqtt/mqttclient.h>

/* Common interface includes                                                 */
#include "network_if.h"
#include "uart_term.h"
#include "json_parse.h"

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

#include <strings.h>







/* Motor files */
#include <ti/drivers/UART.h>
#include "Timer.h"
#include "Motor_Control.h"
#include "Msg_Queue.h"
#include "Motor_CalcPower.h"
#include "SPI_Handle.h"
#include "debug.h"
#include "FreeRTOS.h"
#include "task.h"


/* TI-DRIVERS Header files */
#include "ti_drivers_config.h"

/* Application includes                                                      */
#include "client_cbs.h"

//*****************************************************************************
//                          LOCAL DEFINES
//*****************************************************************************
/* enables secured client                                                    */
//#define SECURE_CLIENT

/* enables client authentication by the server                               */
#define CLNT_USR_PWD

#define CLIENT_INIT_STATE        (0x01)
#define MQTT_INIT_STATE          (0x04)

#define APPLICATION_VERSION      "1.1.1"
#define APPLICATION_NAME         "MQTT client"

#define SLNET_IF_WIFI_PRIO       (5)

/* Operate Lib in MQTT 3.1 mode.                                             */
#define MQTT_3_1_1               false
#define MQTT_3_1                 true

#define WILL_TOPIC               "Client"
#define WILL_MSG                 "Client Stopped"
#define WILL_QOS                 MQTT_QOS_2
#define WILL_RETAIN              false

/* Defining Broker IP address and port Number                                */
//#define SERVER_ADDRESS           "messagesight.demos.ibm.com"
#define SERVER_ADDRESS           "soldier.cloudmqtt.com"
#define SERVER_IP_ADDRESS        "192.168.178.67"
#define PORT_NUMBER              12769
#define SECURED_PORT_NUMBER      22769
#define LOOPBACK_PORT            1882

/* Clean session flag                                                        */
#define CLEAN_SESSION            true

/* Retain Flag. Used in publish message.                                     */
#define RETAIN_ENABLE            1

/* Defining Number of subscription topics                                    */
#define SUBSCRIPTION_TOPIC_COUNT 4

/* Defining Subscription Topic Values                                        */
#define SUBSCRIPTION_TOPIC0      "dev"
#define SUBSCRIPTION_TOPIC1      "pixy"
#define SUBSCRIPTION_TOPIC2      "ultra"
#define SUBSCRIPTION_TOPIC3      "arm"

/* Defining Publish Topic Values                                             */
#define PUBLISH_TOPIC0           "rover"

#define PUBLISH_TOPIC0_DATA \
    "{\"id\": \"rover\", \n\"p\": 1, \n\"r\": 2, \n\"stat\": 10, \n\"atDest\": 10, \n\"time\": 10\n}"

#define PUBLISH_TOPIC1           "topics"//RRR
#define PUBLISH_TOPIC2           "m_Data"//RRR

//#define PUBLISH_TOPIC0_DATA \
//    "{\"distance\": 9\n}"

/* Spawn task priority and Task and Thread Stack Size                        */
#define TASKSTACKSIZE            2048
#define RXTASKSIZE               4096
#define MQTTTHREADSIZE           3048
#define THREADSTACKSIZE          1800
#define SPAWN_TASK_PRIORITY      9

/* secured client requires time configuration, in order to verify server     */
/* certificate validity (date).                                              */

/* Day of month (DD format) range 1-31                                       */
#define DAY                      1
/* Month (MM format) in the range of 1-12                                    */
#define MONTH                    5
/* Year (YYYY format)                                                        */
#define YEAR                     2017
/* Hours in the range of 0-23                                                */
#define HOUR                     12
/* Minutes in the range of 0-59                                              */
#define MINUTES                  33
/* Seconds in the range of 0-59                                              */
#define SEC                      21

/* Number of files used for secure connection                                */
#define CLIENT_NUM_SECURE_FILES  1

/* Expiration value for the timer that is being used to toggle the Led.      */
#define TIMER_EXPIRATION_VALUE   100 * 1000000

//*****************************************************************************
//                      LOCAL FUNCTION PROTOTYPES
//*****************************************************************************
//void pushButtonInterruptHandler2(uint_least8_t index);
//void pushButtonInterruptHandler3(uint_least8_t index);
//void TimerPeriodicIntHandler(sigval val);
//void LedTimerConfigNStart();
//void LedTimerDeinitStop();
static void DisplayBanner(char * AppName);
void * MqttClient(void *pvParameters);
void Mqtt_ClientStop(uint8_t disconnect);
void Mqtt_ServerStop();
void Mqtt_Stop();
void Mqtt_start();
int32_t Mqtt_IF_Connect();
int32_t MqttServer_start();
int32_t MqttClient_start();
int32_t MQTT_SendMsgToQueue(struct msgQueue *queueElement);

//*****************************************************************************
//                 GLOBAL VARIABLES
//*****************************************************************************

/* Connection state: (0) - connected, (negative) - disconnected              */
int32_t published = 0;//RRR
int32_t recieved = 0;//RRR
#define BOARD_ID "rover"
#define INIT_MSG "topics"

int32_t gApConnectionState = -1;
uint32_t gInitState = 0;
uint32_t memPtrCounterfree = 0;
bool gResetApplication = false;
static MQTTClient_Handle gMqttClient;
MQTTClient_Params MqttClientExmple_params;
unsigned short g_usTimerInts;

/* Receive task handle                                                       */
pthread_t g_rx_task_hndl = (pthread_t) NULL;
uint32_t gUiConnFlag = 0;

/* AP Security Parameters                                                    */
SlWlanSecParams_t SecurityParams = { 0 };

/* Client ID                                                                 */
/* If ClientId isn't set, the MAC address of the device will be copied into  */
/* the ClientID parameter.                                                   */
char ClientId[13] = {'\0'};

/* Client User Name and Password                                             */
const char *ClientUsername = "Richard";
const char *ClientPassword = "Ngo";

/* Subscription topics and qos values                                        */
char *topic[SUBSCRIPTION_TOPIC_COUNT] =
{ SUBSCRIPTION_TOPIC0, SUBSCRIPTION_TOPIC1, \
    SUBSCRIPTION_TOPIC2, SUBSCRIPTION_TOPIC3 };

unsigned char qos[SUBSCRIPTION_TOPIC_COUNT] =
{ MQTT_QOS_2, MQTT_QOS_2, MQTT_QOS_2, MQTT_QOS_2 };

/* Publishing topics and messages                                            */
const char *publish_topic = { PUBLISH_TOPIC0 };

const char *subscribed_topics = { PUBLISH_TOPIC1 };//RRR

const char *publish_DebugTopic = { PUBLISH_TOPIC2 };//RRR

const char *publish_data = { PUBLISH_TOPIC0_DATA };

/* Message Queue                                                             */
mqd_t g_PBQueue;
pthread_t mqttThread = (pthread_t) NULL;
pthread_t appThread = (pthread_t) NULL;

//pthread_t timerThread = (pthread_t) NULL;





timer_t g_timer;

/* Printing new line                                                         */
char lineBreak[] = "\n\r";

//*****************************************************************************
//                 Banner VARIABLES
//*****************************************************************************
#ifdef  SECURE_CLIENT

char *Mqtt_Client_secure_files[CLIENT_NUM_SECURE_FILES] = {"ca-cert.pem"};

/*Initialization structure to be used with sl_ExtMqtt_Init API. In order to  */
/*use secured socket method, the flag MQTTCLIENT_NETCONN_SEC, cipher,        */
/*n_files and secure_files must be configured.                               */
/*certificates also must be programmed  ("ca-cert.pem").                     */
/*The first parameter is a bit mask which configures server address type and */
/*security mode.                                                             */
/*Server address type: IPv4, IPv6 and URL must be declared with The          */
/*corresponding flag.                                                        */
/*Security mode: The flag MQTTCLIENT_NETCONN_SEC enables the security (TLS)  */
/*which includes domain name verification and certificate catalog            */
/*verification, those verifications can be disabled by adding to the bit mask*/
/*MQTTCLIENT_NETCONN_SKIP_DOMAIN_NAME_VERIFICATION and                       */
/*MQTTCLIENT_NETCONN_SKIP_CERTIFICATE_CATALOG_VERIFICATION flags             */
/*Example: MQTTCLIENT_NETCONN_IP6 | MQTTCLIENT_NETCONN_SEC |                 */
/*MQTTCLIENT_NETCONN_SKIP_CERTIFICATE_CATALOG_VERIFICATION                   */
/*For this bit mask, the IPv6 address type will be in use, the security      */
/*feature will be enable and the certificate catalog verification will be    */
/*skipped.                                                                   */
/*Note: The domain name verification requires URL Server address type        */
/*      otherwise, this verification will be disabled.                       */
MQTTClient_ConnParams Mqtt_ClientCtx =
{
    MQTTCLIENT_NETCONN_IP4 | MQTTCLIENT_NETCONN_SEC,
    SERVER_IP_ADDRESS,  //SERVER_ADDRESS,
    SECURED_PORT_NUMBER, //  PORT_NUMBER
    SLNETSOCK_SEC_METHOD_SSLv3_TLSV1_2,
    SLNETSOCK_SEC_CIPHER_FULL_LIST,
    CLIENT_NUM_SECURE_FILES,
    Mqtt_Client_secure_files
};

void setTime()
{
    SlDateTime_t dateTime = {0};
    dateTime.tm_day = (uint32_t)DAY;
    dateTime.tm_mon = (uint32_t)MONTH;
    dateTime.tm_year = (uint32_t)YEAR;
    dateTime.tm_hour = (uint32_t)HOUR;
    dateTime.tm_min = (uint32_t)MINUTES;
    dateTime.tm_sec = (uint32_t)SEC;
    sl_DeviceSet(SL_DEVICE_GENERAL, SL_DEVICE_GENERAL_DATE_TIME,
                 sizeof(SlDateTime_t), (uint8_t *)(&dateTime));
}

#else
MQTTClient_ConnParams Mqtt_ClientCtx =
{
    MQTTCLIENT_NETCONN_URL,
    SERVER_ADDRESS,
    PORT_NUMBER, 0, 0, 0,
    NULL
};
#endif

/* Initialize the will_param structure to the default will parameters        */
MQTTClient_Will will_param =
{
    WILL_TOPIC,
    WILL_MSG,
    WILL_QOS,
    WILL_RETAIN
};

//*****************************************************************************
//
//! MQTT_SendMsgToQueue - Utility function that receive msgQueue parameter and
//! tries to push it the queue with minimal time for timeout of 0.
//! If the queue isn't full the parameter will be stored and the function
//! will return 0.
//! If the queue is full and the timeout expired (because the timeout parameter
//! is 0 it will expire immediately), the parameter is thrown away and the
//! function will return -1 as an error for full queue.
//!
//! \param[in] struct msgQueue *queueElement
//!
//! \return 0 on success, -1 on error
//
//*****************************************************************************
int32_t MQTT_SendMsgToQueue(struct msgQueue *queueElement)
{
    struct timespec abstime = {0};

    clock_gettime(CLOCK_REALTIME, &abstime);

    if(g_PBQueue)
    {
        /* send message to the queue                                        */
        if(mq_timedsend(g_PBQueue, (char *) queueElement,
                        sizeof(struct msgQueue), 0, &abstime) == 0)
        {
            return(0);
        }
    }
    return(-1);
}

//*****************************************************************************
//
//! Push Button Handler1(GPIOSW2). Press push button1 (GPIOSW2) Whenever user
//! wants to publish a message. Write message into message queue signaling the
//! event publish messages
//!
//! \param none
//!
//! return none
//
//*****************************************************************************

//*****************************************************************************
//
//! Application startup display on UART
//!
//! \param  none
//!
//! \return none
//!
//*****************************************************************************
static void DisplayBanner(char * AppName)
{
    UART_PRINT("\n\n\n\r");
    UART_PRINT("\t\t *************************************************\n\r");
    UART_PRINT("\t\t    CC32xx %s Application       \n\r", AppName);
    UART_PRINT("\t\t *************************************************\n\r");
    UART_PRINT("\n\n\n\r");
}

void * MqttClientThread(void * pvParameters)
{
    //dbgOutputLoc(DBG_MqttClientThread_START);
    struct msgQueue queueElement;
    struct msgQueue queueElemRecv;

    MQTTClient_run((MQTTClient_Handle)pvParameters);

    queueElement.event = LOCAL_CLIENT_DISCONNECTION;
    queueElement.msgPtr = NULL;

    /*write message indicating disconnect Broker message.                   */
    if(MQTT_SendMsgToQueue(&queueElement))
    {
        UART_PRINT(
            "\n\n\rQueue is full, throw first msg and send the new one\n\n\r");
        mq_receive(g_PBQueue, (char*) &queueElemRecv, sizeof(struct msgQueue),
                   NULL);
        MQTT_SendMsgToQueue(&queueElement);
    }

    pthread_exit(0);

    return(NULL);
}







/*
void * roverSim(void *pvParameters)//RRR
{

    struct msgQueue queueElement;

    queueElement.event = PUBLISH_SUBSCRIPTIONS;
    //queueElement.event = PUBLISH_TO_ROVER;
    queueElement.msgPtr = NULL;
    queueElement.rovStatus = 0;
    queueElement.rovDestination = 0;
    queueElement.rovTime = 0;

    Timer_Handle timer0;
    Timer_Params params;


    Timer_init();



    Timer_Params_init(&params);
    params.period = 1000000;
    params.periodUnits = Timer_PERIOD_US;

    timer0 = Timer_open(CONFIG_TIMER_0, &params);

    if (timer0 == NULL) {

        while (1) {}
    }


    if (Timer_start(timer0) == Timer_STATUS_ERROR) {

        while (1) {}
    }
    while(1){

        queueElement.rovStatus = queueElement.rovStatus + 1;
        queueElement.rovDestination = queueElement.rovDestination + 2;
        queueElement.rovTime = queueElement.rovTime + 3;
        // write message indicating publish message
       if(MQTT_SendMsgToQueue(&queueElement))
       {
           UART_PRINT("\n\n\rQueue is full\n\n\r");
       }
       queueElement.event = PUBLISH_TO_ROVER;

        if (Timer_start(timer0) == Timer_STATUS_ERROR) {
            // Failed to start timer
            while (1) {}
        }

    }

}
*/

void *motorControl(void *arg0){
    msg msg_Command;

    uint8_t baudset = 0xAA;
    UART_write(uart, &baudset, sizeof(baudset));

    while(1)
    {
        msg_Command = readFromCommandQueue();
        if(msg_Command.here){
            Set_Motors(msg_Command.data);
        }
    }
}

void *motorUpdateSpeeds (void *arg0){
    msg msg_Encoder;

    //dbgUARTStr("START: ");

    while(1)
    {
        msg_Encoder = readFromEncoderQueue();//SPI
        if(msg_Encoder.here){
            update_Motors(msg_Encoder.data);
        }
        /*
        else{
            setGoals_PID(msg_Encoder.data[0],msg_Encoder.data[1],msg_Encoder.data[2]);
        }
        */
    }
}




void * motorDecide(void * arg0) {
    struct msgQueue queueElement;

    //queueElement.event = PUBLISH_SUBSCRIPTIONS;
    queueElement.event = PUBLISH_TO_m_Data;
    queueElement.msgPtr = NULL;
    queueElement.rovStatus = 0;
    queueElement.rovDestination = 0;
    queueElement.rovTime = 0;
    queueElement.rovTrav1 = 0;
    queueElement.rovTrav2 = 0;
    queueElement.rovTrav3 = 0;
    queueElement.rovSpeed1 = 0;
    queueElement.rovSpeed2 = 0;
    queueElement.rovSpeed3 = 0;

    dev_data msg_MQTT;


    const int check_dist = 20; //close enough for pixycam to determine if safe, 8cm

    const int rover_size_ang = 170; //tics of angle to turn to check if rover to fit
    const int rover_size = 600; //size of rover in tics
    const int safe_dist = 40; //the double size of the rover itself, maybe a bit more, in units of sensor
    const int circle_ang = 1600; //tics for rover to do a full circle
    const int pullback_size = 600; //tics for rover to do a safe pullback (rover_size?)
    const int safeStrafe_dist = 40; //distance to space from wall while strafing

    const int partCheck_ang = circle_ang; //choice within ideal spot

    const int dangerSoft_dist = 15; //likely that rover is drifting torwards wall
    const int dangerHard_dist = 10; //likely that rover is about to bump into wall

    const int ang_thresh = 15; //if rover is close enough to it's goal orientation
    const int close = 15; //signals if rover should slow rotation down

    //avoiding states
    const int findPath = 0;
    const int followWall = 1;
    const int checkPath = 2;
    const int align = 3;
    const int freedom = 4;
    const int TurnA = 5;
    const int MoveFor = 6;
    const int CheckOpen = 7;
    const int ClearedCheck = 8;

    //tracking states
    const int following = 0;
    const int searching = 1;
    const int adjusting = 2;
    const int atDest = 3;
    const int makeSpace = 4;

    //variables from mqtt msgs
    int detect_dist = 6000;
    bool in_sight = false;
    int carrot = 0;
    bool arrived = false;
    bool avoiding = false;
    int origin_travel = 0;
    int carrot_dir = 1;
    int goal_dir = 1;
    int current_travel[3];
    int current_speeds[3];
    bool ready = true;
    bool armState = false;
    bool pastArmState = false;

    int avoid_state = findPath;
    int avoid_nextState = findPath;

    int track_state = following;

    //findPath
    int openStart = 0;
    int check_dir = 1;
    int alignAng = 0;
    bool opening = false;
    //followWall
    int scout_size = rover_size * 2;
    int pullback_start = 0;
    bool dangerHard = false;
    bool dangerSoft = false;
    int leeway = 0;
    int edgestart = 0;
    //checkPath
    bool trapped = false;
    //align
    int turn_dir = 1;
    int move_begin = 0;

    //following
    int slower = 0;


    int goalSig = 0;


    int pastCarrot = 0;
    bool debounced = false;
    bool danger = false;
    bool clear = false;
    while (1) {

        msg_MQTT = readFromMQTTQueue(); //SPI
        //UART_PRINT("%d",track_state);
        if (strcmp(msg_MQTT.id, "ultra") == 0) {
            //d.dist
            //d.time
            detect_dist = msg_MQTT.dist;
            UART_PRINT("ultra: %d, track: %d, avoid: %d \r\n",detect_dist, track_state, avoid_state);
        }//US sensor

        if (strcmp(msg_MQTT.id, "pixy") == 0) {
            //d.time
            //d.x
            //d.y
            //d.width
            //d.height
            //d.signature
            //UART_PRINT("sig: %d, goal: %d\r\n",msg_MQTT.signature, goalSig);
            if(msg_MQTT.signature == goalSig){
                in_sight = true;




            if (msg_MQTT.width > 60 || msg_MQTT.height > 60) {
                arrived = true;

            }

            carrot = msg_MQTT.x;
            if (carrot == pastCarrot){
                debounced = true;

            }else{
                debounced = false;
            }
            pastCarrot = carrot;


            if (carrot < 160) {
                carrot_dir = 1;
            } else {
                carrot_dir = -1;

            }
            }
            else{
                in_sight = false;

            }
            //UART_PRINT("PIXY: %d \r\n",carrot);
        } //pixy


        if (strcmp(msg_MQTT.id, "arm") == 0) {
            //d.status
            if (strcmp(msg_MQTT.status, "retrieved") == 0) {
                armState = true;
            }
            else{
                armState = false;
            }

        }//arm


        if (strcmp(msg_MQTT.id, "motors") == 0) {
            current_travel[0] = msg_MQTT.travel[0];
            current_travel[1] = msg_MQTT.travel[1];
            current_travel[2] = msg_MQTT.travel[2];

            current_speeds[0] = msg_MQTT.speed[0];
            current_speeds[1] = msg_MQTT.speed[1];
            current_speeds[2] = msg_MQTT.speed[2];


            queueElement.rovTrav1 = msg_MQTT.travel[0];
            queueElement.rovTrav2 = msg_MQTT.travel[1];
            queueElement.rovTrav3 = msg_MQTT.travel[2];

            queueElement.rovSpeed1 = msg_MQTT.speed[0];
            queueElement.rovSpeed2 = msg_MQTT.speed[1];
            queueElement.rovSpeed3 = msg_MQTT.speed[2];

            if(msg_MQTT.speed[0] == 0 && msg_MQTT.speed[1] == 0 && msg_MQTT.speed[2] == 0){
                ready = true;


            }
            else{
                ready = false;

            }

        }

        if (strcmp(msg_MQTT.id, "dev") == 0) {
            if(msg_MQTT.mode == 1){
                setGoals_PID(msg_MQTT.speed[0], msg_MQTT.speed[1], msg_MQTT.speed[2]);
                UART_PRINT("s1: %d, s2: %d, s3: %d \r\n", msg_MQTT.speed[0], msg_MQTT.speed[1], msg_MQTT.speed[2]);
            }
            else if(msg_MQTT.mode == 2){
                setKp_PID(msg_MQTT.kp[0], msg_MQTT.kp[1], msg_MQTT.kp[2]);
                UART_PRINT("kp1: %f, kp2: %f, kp3: %f \r\n", msg_MQTT.kp[0], msg_MQTT.kp[1], msg_MQTT.kp[2]);
            }
            else if(msg_MQTT.mode == 3){
                setKi_PID(msg_MQTT.ki[0], msg_MQTT.ki[1], msg_MQTT.ki[2]);
                UART_PRINT("ki1: %f, ki2: %f, ki3: %f \r\n", msg_MQTT.ki[0], msg_MQTT.ki[1], msg_MQTT.ki[2]);
            }
            else if(msg_MQTT.mode == 4){
                goalSig = msg_MQTT.speed[0];

            }



        }


        if(goalSig == 0){
            continue;
        }


        //all values initalized and gotten
        if (arrived == true && detect_dist < 10) {

            setGoals_PID(0, 0, 0);
            //SendAtDest();
            track_state = atDest;
            //turn to goal as best as possible
            //move until close enough for handling
            //send a atDest message when done

        }



        if (detect_dist < check_dist && avoiding == false && arrived == false) {
            setGoals_PID(0, 0, 0);
            danger = true;
            if (ready) {
                avoiding = true;
                avoid_state = 5;
                check_dir = 1;
                alignAng = 0;
                opening = false;
                dangerHard = false;
                dangerSoft = false;
                leeway = 0;
                trapped = false;

                origin_travel = current_travel[2];

                goal_dir = carrot_dir;

                openStart = current_travel[0];

                setGoals_PID(10 * goal_dir, 10 * goal_dir, 10 * goal_dir);

                danger = false;
            }
        }

        if (avoiding) {
            switch (avoid_state) {
            case TurnA:
                if (detect_dist>safe_dist){

                    if (clear == false){
                        openStart = current_travel[0];
                        clear = true;
                    }
                    else if (abs(current_travel[0] - openStart) >= circle_ang/24){
                            setGoals_PID(0,0,0);

                    }



                }



                if(ready && openStart != current_travel[0]){
                    setGoals_PID(-20,20,0);
                    avoid_state = MoveFor;
                    openStart = current_travel[0];
                    clear = false;
                }


            break;
            case MoveFor:
                if (abs(current_travel[0] - openStart) >= rover_size){
                    setGoals_PID(0,0,0);

                }
                if (detect_dist<safe_dist){
                    setGoals_PID(0,0,0);

                }
                if(ready && openStart != current_travel[0]){
                    if(opening){
                        avoiding = false;

                        track_state = 1;
                    }
                    else if (detect_dist<safe_dist && trapped == false){
                        goal_dir *= -1;
                        setGoals_PID(10 * goal_dir, 10 * goal_dir, 10 * goal_dir);
                        avoid_state = TurnA;
                        trapped = true;
                    }
                    else{
                    setGoals_PID(10 * -goal_dir, 10 * -goal_dir, 10 * -goal_dir);
                    avoid_state = CheckOpen;

                    }
                    openStart = current_travel[0];
                }
            break;
            case CheckOpen:
                if (abs(current_travel[0] - openStart) >= circle_ang/4 + circle_ang/24){
                    setGoals_PID(0,0,0);

                }
                if(ready && openStart != current_travel[0]){
                    if(detect_dist>safe_dist){
                        //setGoals_PID(10 * goal_dir, 10 * goal_dir, 10 * goal_dir);
                        avoid_state = ClearedCheck;

                    }
                    else{
                        //setGoals_PID(10 * goal_dir, 10 * goal_dir, 10 * goal_dir);
                        avoid_state = TurnA;

                    }
                    setGoals_PID(10 * goal_dir, 10 * goal_dir, 10 * goal_dir);
                    openStart = current_travel[0];
                }


                break;
            case ClearedCheck:
                if (abs(current_travel[0] - openStart) >= circle_ang/24){
                    setGoals_PID(0,0,0);

                }
                if(ready && openStart != current_travel[0]){
                    if(detect_dist>safe_dist){
                        setGoals_PID(-20,20,0);
                        avoid_state = MoveFor;
                        opening = true;

                    }
                    else{
                        setGoals_PID(10 * goal_dir, 10 * goal_dir, 10 * goal_dir);
                        avoid_state = TurnA;

                    }
                    openStart = current_travel[0];
                }


                break;


            case findPath:

                if (detect_dist > safe_dist && opening == false) {
                    openStart = current_travel[2];
                    opening = true;
                    UART_PRINT("AOPENED");
                }

                if (opening == true && abs(current_travel[2] - origin_travel) < partCheck_ang && abs(current_travel[2] - openStart) < rover_size_ang / 2) {
                    scout_size = detect_dist;
                }

                if ((detect_dist < safe_dist || abs(current_travel[2] - origin_travel) > circle_ang) && opening == true) {
                    opening = false;
                    UART_PRINT("ACLOSED");
                    if (abs(current_travel[2] - openStart) >= rover_size_ang) {

                        if (abs(current_travel[2] - origin_travel) < partCheck_ang) {
                            UART_PRINT("Here1");
                            setGoals_PID(0, 0, 0);
                            alignAng = openStart + rover_size_ang / 2 * goal_dir;
                            avoid_state = align;
                            avoid_nextState = followWall;
                            edgestart = current_travel[2];
                            check_dir = 1;

                        } else {
                            scout_size = safe_dist;
                            if (alignAng == 0) {
                                alignAng = openStart + rover_size_ang / 2 * goal_dir;
                                check_dir = 1;
                            } else {

                                if (check_dir == 1 && abs(current_travel[2] - rover_size_ang / 2 * goal_dir - (circle_ang * goal_dir + origin_travel)) <= abs(alignAng - origin_travel)) { //closest to origin
                                    alignAng = current_travel[2] - rover_size_ang / 2 * goal_dir;
                                    check_dir = -1;

                                }
                                if (check_dir == -1 && abs(current_travel[2] - rover_size_ang / 2 * goal_dir - (circle_ang * goal_dir + origin_travel)) <= abs(alignAng - (circle_ang * goal_dir + origin_travel))) { //closest to origin
                                    alignAng = current_travel[2] - rover_size_ang / 2 * goal_dir;

                                }
                            }

                        }

                    }
                }
                if (abs(current_travel[2] - origin_travel) > circle_ang) {
                    if (alignAng == 0) {
                        avoiding = false; //search again... also reinitialize
                    } else {
                        UART_PRINT("Here2");
                        setGoals_PID(0, 0, 0);

                        avoid_state = align;
                        avoid_nextState = followWall;
                        edgestart = current_travel[2];
                    }

                }

                break;
            case followWall:

                if (dangerHard) {
                    if (abs(current_travel[0] - pullback_start) >= pullback_size) {
                        avoiding = false; //
                        dangerHard = false;
                    }

                } else {
                    if (detect_dist >= safeStrafe_dist + leeway) {

                        if (abs(current_travel[2] - edgestart) >= rover_size) {
                            setGoals_PID(0, 0, 0);
                            if (ready) {
                                move_begin = current_travel[0];
                                setGoals_PID(-20, 20, 0); //forward
                                in_sight = false;
                                avoid_state = freedom;
                            }

                        }
                        if (dangerSoft == true) {
                            setGoals_PID(0, 0, 0);
                            if (ready) {
                                if (check_dir*goal_dir > 0) { //strafe
                                    setGoals_PID(0, 20, -20);
                                } else {
                                    setGoals_PID(-20, 0, 20);
                                }
                                leeway = 0;
                                dangerSoft = false;
                            }
                        }

                    } else {

                        edgestart = current_travel[2];

                        if (detect_dist <= dangerHard_dist) {

                            setGoals_PID(0, 0, 0);
                            if (ready) {

                                pullback_start = current_travel[0];
                                setGoals_PID(20, -20, 0); //strafeaway
                                dangerHard = true;
                            }

                        } else if (detect_dist <= dangerSoft_dist && dangerSoft == false) { //don't enter here more than twice in a row
                            setGoals_PID(0, 0, 0);
                            if (ready) {
                                if (check_dir*goal_dir > 0) { //strafeback
                                    setGoals_PID(20, 0, -20);
                                } else {
                                    setGoals_PID(0, -20, 20);
                                }
                                leeway = 10;
                                dangerSoft = true;
                            }

                        }

                    }

                    if (abs(current_travel[2] - move_begin) > scout_size) {

                        setGoals_PID(0, 0, 0);
                        if (ready) {
                            move_begin = current_travel[2];
                            setGoals_PID(check_dir*goal_dir * 10, check_dir*goal_dir * 10, check_dir*goal_dir * 10);
                            avoid_state = checkPath;
                        }

                    }
                }
                break;
            case checkPath:

                if (abs(current_travel[2] - move_begin) >= circle_ang / 4) {
                    if (detect_dist >= safe_dist) {
                        alignAng = move_begin;
                        setGoals_PID(0, 0, 0);
                        avoid_state = align;
                        avoid_nextState = followWall;

                    } else if (trapped) {
                        avoiding = false;
                        trapped = false;
                    } else {
                        alignAng = current_travel[2] - circle_ang * (150 / 360) * check_dir*goal_dir; ///go back to the otherside
                        setGoals_PID(0, 0, 0);
                        avoid_state = align;
                        avoid_nextState = checkPath;
                        check_dir *= -1;

                        trapped = true;
                    }
                } else if (abs(current_travel[2] - move_begin) <= circle_ang / 6 && detect_dist >= safe_dist) {
                    scout_size = detect_dist;
                }

                break;
            case freedom:
                if (abs(current_travel[0] - move_begin) > rover_size || arrived) {
                    setGoals_PID(0, 0, 0);
                    if (ready) {

                        avoiding = false; //back to search
                    }
                }

                break;
            case align:

                if (abs(current_travel[2] - alignAng) <= ang_thresh) {
                    setGoals_PID(0, 0, 0);
                    if (ready) {
                        avoid_state = avoid_nextState;
                        move_begin = current_travel[2];

                        if (avoid_nextState == followWall) {
                            if (check_dir*goal_dir > 0) { //strafe
                                setGoals_PID(0, 20, -20);
                                UART_PRINT("TOWARDS_RIGHT");
                            } else {
                                setGoals_PID(-20, 0, 20);
                                UART_PRINT("TOWARDS_LEFT");
                            }

                        }

                    }

                }
                if (ready) {
                    //find closest direction torwards angle
                    /*
                    if (abs(alignAng - current_travel[2]) < circle_ang / 2) {
                        if (alignAng - current_travel[2] > 0) {
                            turn_dir = 1;
                        } else {
                            turn_dir = -1;
                        }

                    } else {
                        if (alignAng - current_travel[2] > 0) {
                            turn_dir = -1;
                        } else {
                            turn_dir = 1;
                        }

                    }
                    */
                    if (alignAng - current_travel[2] > 0) {
                        turn_dir = 1;
                    } else {
                        turn_dir = -1;
                    }
                    if (abs(current_travel[2] - alignAng) > close) {
                        setGoals_PID(turn_dir * 10, turn_dir * 10, turn_dir * 10);
                    } else {
                        setGoals_PID(turn_dir * 5, turn_dir * 5, turn_dir * 5);
                    }
                }

            }

        } else if(danger == false) {//123

            switch (track_state) {
            case following:
                if (in_sight == false) { //cant find
                    setGoals_PID(0, 0, 0);
                    track_state = searching;
                } else {
                    if (carrot < 120) {
                        setGoals_PID(0, 0, 0);
                        if (ready) {
                            setGoals_PID(10, 10, 10);
                            track_state = adjusting;

                        }

                    } else if (carrot > 200) {
                        setGoals_PID(0, 0, 0);
                        if (ready) {
                            setGoals_PID(-10, -10, -10);
                            track_state = adjusting;

                        }

                    } else {
                        if (arrived && detect_dist <= 20) {
                            slower = 20 - detect_dist;

                        } else {
                            slower = 0;
                        }

                        setGoals_PID(-(20 - slower), (20 - slower), 0); //if dosen't get interrupted by avoiding, is what gets to goal.

                    }

                }
                break;
            case adjusting:
                if (in_sight == false) { //cant find
                    setGoals_PID(0, 0, 0);
                    track_state = searching;
                }
                //UART_PRINT("carrot_dir: %d, carrot: % ", carrot_dir, carrot);
                //if ((carrot_dir > 0 && carrot > 145) || (carrot_dir < 0 && carrot < 175)) {
                if ((carrot > 150) && (carrot < 170)) {

                    setGoals_PID(0, 0, 0);

                    if (ready && debounced) {
                        UART_PRINT("Forward");
                        setGoals_PID(-(20 - slower), (20 - slower), 0);//
                        track_state = following;

                    }

                }
                else if(carrot >= 170){
                    setGoals_PID(-10,-10,-10);

                }else{
                    setGoals_PID(10,10,10);

                }


                break;
            case searching:

                if (ready) {
                    //if(arrived)
                    setGoals_PID(10 * carrot_dir, 10 * carrot_dir, 10 * carrot_dir);

                }
                if (in_sight == true) {

                    track_state = adjusting;

                }
                break;
            case atDest:
                UART_PRINT("GOAL");
                if (armState != pastArmState) {
                    setGoals_PID(20, -20, 0);
                    openStart = current_travel[0];
                    track_state = makeSpace;
                    pastArmState = armState;
                }
                break;
            case makeSpace:

                if (abs(current_travel[0] - openStart) >= rover_size) {
                    setGoals_PID(0, 0, 0);
                    if(goalSig > 0){
                        goalSig*=-1;
                    }
                    else{
                        goalSig = 0;
                    }
                    track_state = following;

                }
                break;
            }
        }
        if(ReadTimer_Check(3)){


                    if(MQTT_SendMsgToQueue(&queueElement))
                    {
                        UART_PRINT("\n\n\rQueue is full\n\n\r");
                    }


        }


        //send to queue

    } //while

    //sendToEncoderQueue(msg_Input);
}

//*****************************************************************************
//
//! Task implementing MQTT Server plus client bridge
//!
//! This function
//!    1. Initializes network driver and connects to the default AP
//!    2. Initializes the mqtt client ans server libraries and set up MQTT
//!       with the remote broker.
//!    3. set up the button events and their callbacks(for publishing)
//!    4. handles the callback signals
//!
//! \param  none
//!
//! \return None
//!
//*****************************************************************************
void * MqttClient(void *pvParameters)
{
    //dbgOutputLoc(DBG_MqttClient_START);
    struct msgQueue queueElemRecv;
    long lRetVal = -1;
    char *tmpBuff;


    /*Initializing Client and Subscribing to the Broker.                     */
    if(gApConnectionState >= 0)
    {
        lRetVal = MqttClient_start();
        if(lRetVal == -1)
        {
            UART_PRINT("MQTT Client lib initialization failed\n\r");
            pthread_exit(0);
            return(NULL);
        }
    }



    MQ_init();

    Timer_init();
    UART_init();
    GPIO_init();

    Init_ReadTimer();
    Init_Encoder();


    Init_Motor();
    Init_Debug();
    Init_PID();


    pthread_t           thread0, thread1, thread2;
    pthread_attr_t      attrs;
    struct sched_param  priParam;
    int                 retc;
    int                 detachState;


    // Create application threads
    pthread_attr_init(&attrs);

    detachState = PTHREAD_CREATE_DETACHED;
    // Set priority and stack size attributes
    retc = pthread_attr_setdetachstate(&attrs, detachState);
    if (retc != 0) {
        // pthread_attr_setdetachstate() failed
        while (1);
    }

    retc |= pthread_attr_setstacksize(&attrs, THREADSTACKSIZE);
    if (retc != 0) {
        // pthread_attr_setstacksize() failed
        while (1);
    }

    // Create threadFxn0 thread
    priParam.sched_priority = 2;
    pthread_attr_setschedparam(&attrs, &priParam);

    retc = pthread_create(&thread0, &attrs, motorUpdateSpeeds, NULL);
    if (retc != 0) {
        // pthread_create() failed
        while (1);
    }

    // Create threadFxn1 thread
    retc = pthread_create(&thread1, &attrs, motorControl, NULL);
    if (retc != 0) {
        // pthread_create() failed
        while (1);
    }

    // Create threadFxn1 thread
    retc = pthread_create(&thread2, &attrs, motorDecide, NULL);
    if (retc != 0) {
        // pthread_create() failed
        while (1);
    }


    char pub_data[60];
        for(;; )
        {
            //dbgOutputLoc(DBG_MqttClient_WAITFORSIG);
            /*waiting for signals                                                */
            mq_receive(g_PBQueue, (char*) &queueElemRecv, sizeof(struct msgQueue),
                       NULL);

            switch(queueElemRecv.event)
            {
            case PUBLISH_TO_ROVER:
                published = published+1;
                //dbgOutputLoc(DBG_MqttClient_PUBLISH);
                /*send publish message                                       */



                //UPDATE THE atDestination and status variables to use this one
                sprintf(pub_data, "{\"id\": \"%s\", \n\"p\": %d, \n\"r\": %d, \n\"stat\": %d, \n\"atDest\": %d, \n\"time\": %d\n}", BOARD_ID, published, recieved, queueElemRecv.rovStatus, queueElemRecv.rovDestination, queueElemRecv.rovTime);



                lRetVal =
                    MQTTClient_publish(gMqttClient, (char*) publish_topic, strlen(
                                          (char*)publish_topic),
                                          pub_data,
                                      strlen(pub_data), MQTT_QOS_2 |
                                      ((RETAIN_ENABLE) ? MQTT_PUBLISH_RETAIN : 0));



                UART_PRINT("\n\r CC3200 Publishes the following message \n\r");
                UART_PRINT("Topic: %s\n\r", publish_topic);
                //UART_PRINT("Data: %s\n\r", pub_data);

                /* Clear and enable again the SW2 interrupt */
                //GPIO_clearInt(CONFIG_GPIO_BUTTON_0);     // SW2
                //GPIO_enableInt(CONFIG_GPIO_BUTTON_0);     // SW2

                break;
            case PUBLISH_TO_m_Data:
                published = published+1;
                //dbgOutputLoc(DBG_MqttClient_PUBLISH);
                /*send publish message                                       */



                //sprintf(pub_data, "{\"id\": \"%s\", \n\"pub\": %d, \n\"rec\": %d, \n\"status\": %d, \n\"atDest\": %d, \n\"t1\": %d, \n\"t2\": %d, \n\"t3\": %d, \n\"s1\": %d, \n\"s2\": %d, \n\"s3\": %d, \n\"time\": %d\n}", BOARD_ID, published, recieved, queueElemRecv.rovStatus, queueElemRecv.rovDestination, queueElemRecv.rovTrav1, queueElemRecv.rovTrav2, queueElemRecv.rovTrav3, queueElemRecv.rovSpeed1, queueElemRecv.rovSpeed2, queueElemRecv.rovSpeed3, queueElemRecv.rovTime);
                sprintf(pub_data, "{\"id\": \"%s\", \n\"t1\": %d, \n\"t2\": %d, \n\"t3\": %d, \n\"s1\": %d, \n\"s2\": %d, \n\"s3\": %d}", BOARD_ID, queueElemRecv.rovTrav1, queueElemRecv.rovTrav2, queueElemRecv.rovTrav3, queueElemRecv.rovSpeed1, queueElemRecv.rovSpeed2, queueElemRecv.rovSpeed3);
                //sprintf(pub_data, "{\"id\": \"%s\", \n\"s1\": %d, \n\"s2\": %d, \n\"s3\": %d\n}", BOARD_ID, queueElemRecv.rovSpeed1, queueElemRecv.rovSpeed2, queueElemRecv.rovSpeed3);

                lRetVal =
                    MQTTClient_publish(gMqttClient, (char*) publish_DebugTopic, strlen(
                                          (char*)publish_DebugTopic),
                                          pub_data,
                                      strlen(pub_data), MQTT_QOS_2 |
                                      ((RETAIN_ENABLE) ? MQTT_PUBLISH_RETAIN : 0));

                //UART_PRINT("\n\r CC3200 Publishes the following message \n\r");
                //UART_PRINT("Topic: %s\n\r", publish_DebugTopic);
                //UART_PRINT("Data: %s\n\r", pub_data);

                /* Clear and enable again the SW2 interrupt */
                //GPIO_clearInt(CONFIG_GPIO_BUTTON_0);     // SW2
                //GPIO_enableInt(CONFIG_GPIO_BUTTON_0);     // SW2

                break;
            case PUBLISH_SUBSCRIPTIONS:
                        published = published+1;

                        sprintf(pub_data, "{\"id\": \"%s\", \n\"p\": %d, \n\"r\": %d, \n\"t1\": \"pixy\", \n\"t2\": \"ultra\", \n\"t3\": \"\", \n\"t4\": \"\" \n}", BOARD_ID, published, recieved);


                        lRetVal =
                            MQTTClient_publish(gMqttClient, (char*) subscribed_topics, strlen(
                                                  (char*)subscribed_topics),
                                                  pub_data,
                                              strlen(pub_data), MQTT_QOS_2 |
                                              ((RETAIN_ENABLE) ? MQTT_PUBLISH_RETAIN : 0));




                        UART_PRINT("\n\r CC3200 Publishes the following message \n\r");
                        UART_PRINT("Topic: %s\n\r", subscribed_topics);
                        //UART_PRINT("Data: %s\n\r", pub_data);
                break;
            /*msg received by client from remote broker (on a topic      */
            /*subscribed by local client)                                */
            case MSG_RECV_BY_CLIENT:
                //dbgOutputLoc(DBG_MqttClient_RECIEVE);
                recieved = recieved+1;
                tmpBuff = (char *) ((char *) queueElemRecv.msgPtr + 12);
                if(strncmp
                    (tmpBuff, SUBSCRIPTION_TOPIC1, queueElemRecv.topLen) == 0)
                {
                    //GPIO_toggle(CONFIG_GPIO_LED_0);
                }
                else if(strncmp(tmpBuff, SUBSCRIPTION_TOPIC2,
                                queueElemRecv.topLen) == 0)
                {
                    //GPIO_toggle(CONFIG_GPIO_LED_1);
                }
                else if(strncmp(tmpBuff, SUBSCRIPTION_TOPIC3,
                                queueElemRecv.topLen) == 0)
                {
                    //GPIO_toggle(CONFIG_GPIO_LED_2);
                }

                free(queueElemRecv.msgPtr);
                break;

            /*On-board client disconnected from remote broker, only      */
            /*local MQTT network will work                               */
            case LOCAL_CLIENT_DISCONNECTION:
                UART_PRINT("\n\rOn-board Client Disconnected\n\r\r\n");
                gUiConnFlag = 0;
                break;

            /*Push button for full restart check                         */
            case DISC_PUSH_BUTTON_PRESSED:
                gResetApplication = true;
                break;

            case THREAD_TERMINATE_REQ:
                gUiConnFlag = 0;
                pthread_exit(0);
                return(NULL);
            default:
                gResetApplication = true;
                gUiConnFlag = 0;
                pthread_exit(0);
                return(NULL);
            }
        }


    return (NULL);
}

//*****************************************************************************
//
//! This function connect the MQTT device to an AP with the SSID which was
//! configured in SSID_NAME definition which can be found in Network_if.h file,
//! if the device can't connect to to this AP a request from the user for other
//! SSID will appear.
//!
//! \param  none
//!
//! \return None
//!
//*****************************************************************************
int32_t Mqtt_IF_Connect()
{
    int32_t lRetVal;
    char SSID_Remote_Name[32];
    int8_t Str_Length;

    memset(SSID_Remote_Name, '\0', sizeof(SSID_Remote_Name));
    Str_Length = strlen(SSID_NAME);

    if(Str_Length)
    {
        /*Copy the Default SSID to the local variable                        */
        strncpy(SSID_Remote_Name, SSID_NAME, Str_Length);
    }

    /*Display Application Banner                                             */
    DisplayBanner(APPLICATION_NAME);

    //GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
    //GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
    //GPIO_write(CONFIG_GPIO_LED_2, CONFIG_GPIO_LED_OFF);

    /*Reset The state of the machine                                         */
    Network_IF_ResetMCUStateMachine();

    /*Start the driver                                                       */
    lRetVal = Network_IF_InitDriver(ROLE_STA);
    if(lRetVal < 0)
    {
        UART_PRINT("Failed to start SimpleLink Device\n\r", lRetVal);
        return(-1);
    }

    /*switch on CONFIG_GPIO_LED_2 to indicate Simplelink is properly up.       */
    //GPIO_write(CONFIG_GPIO_LED_2, CONFIG_GPIO_LED_ON);

    /*Start Timer to blink CONFIG_GPIO_LED_0 till AP connection                */
    //LedTimerConfigNStart();

    /*Initialize AP security params                                          */
    SecurityParams.Key = (signed char *) SECURITY_KEY;
    SecurityParams.KeyLen = strlen(SECURITY_KEY);
    SecurityParams.Type = SECURITY_TYPE;

    /*Connect to the Access Point                                            */
    lRetVal = Network_IF_ConnectAP(SSID_Remote_Name, SecurityParams);
    if(lRetVal < 0)
    {
        UART_PRINT("Connection to an AP failed\n\r");
        return(-1);
    }

    /*Disable the LED blinking Timer as Device is connected to AP.           */
    //LedTimerDeinitStop();

    /*Switch ON CONFIG_GPIO_LED_0 to indicate that Device acquired an IP.      */
    //GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    //sleep(1);

    //GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
    //GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
    //GPIO_write(CONFIG_GPIO_LED_2, CONFIG_GPIO_LED_OFF);

    return(0);
}

//*****************************************************************************
//!
//! MQTT Start - Initialize and create all the items required to run the MQTT
//! protocol
//!
//! \param  none
//!
//! \return None
//!
//*****************************************************************************
void Mqtt_start()
{
    int32_t threadArg = 100;
    pthread_attr_t pAttrs;
    struct sched_param priParam;
    int32_t retc = 0;
    mq_attr attr;
    unsigned mode = 0;

    /*sync object for inter thread communication                             */
    attr.mq_maxmsg = 10;
    attr.mq_msgsize = sizeof(struct msgQueue);
    g_PBQueue = mq_open("g_PBQueue", O_CREAT, mode, &attr);

    if(g_PBQueue == NULL)
    {
        UART_PRINT("MQTT Message Queue create fail\n\r");
        gInitState &= ~MQTT_INIT_STATE;
        return;
    }

    /*Set priority and stack size attributes                                 */
    pthread_attr_init(&pAttrs);
    priParam.sched_priority = 2;
    retc = pthread_attr_setschedparam(&pAttrs, &priParam);
    retc |= pthread_attr_setstacksize(&pAttrs, MQTTTHREADSIZE);
    retc |= pthread_attr_setdetachstate(&pAttrs, PTHREAD_CREATE_DETACHED);

    if(retc != 0)
    {
        gInitState &= ~MQTT_INIT_STATE;
        UART_PRINT("MQTT thread create fail\n\r");
        return;
    }

    retc = pthread_create(&mqttThread, &pAttrs, MqttClient, (void *) &threadArg);
    if(retc != 0)
    {
        gInitState &= ~MQTT_INIT_STATE;
        UART_PRINT("MQTT thread create fail\n\r");
        return;
    }

    /*enable interrupt for the GPIO 13 (SW3) and GPIO 22 (SW2).              */
    //GPIO_setCallback(CONFIG_GPIO_BUTTON_0, pushButtonInterruptHandler2);
    //GPIO_enableInt(CONFIG_GPIO_BUTTON_0); // SW2

    //GPIO_setCallback(CONFIG_GPIO_BUTTON_1, pushButtonInterruptHandler3);
    //GPIO_enableInt(CONFIG_GPIO_BUTTON_1); // SW3

    gInitState &= ~MQTT_INIT_STATE;
}

//*****************************************************************************
//!
//! MQTT Stop - Close the client instance and free all the items required to
//! run the MQTT protocol
//!
//! \param  none
//!
//! \return None
//!
//*****************************************************************************

void Mqtt_Stop()
{
    struct msgQueue queueElement;
    struct msgQueue queueElemRecv;

    if(gApConnectionState >= 0)
    {
        Mqtt_ClientStop(1);
    }

    queueElement.event = THREAD_TERMINATE_REQ;
    queueElement.msgPtr = NULL;

    /*write message indicating publish message                               */
    if(MQTT_SendMsgToQueue(&queueElement))
    {
        UART_PRINT(
            "\n\n\rQueue is full, throw first msg and send the new one\n\n\r");
        mq_receive(g_PBQueue, (char*) &queueElemRecv, sizeof(struct msgQueue),
                   NULL);
        MQTT_SendMsgToQueue(&queueElement);
    }

    sleep(2);

    mq_close(g_PBQueue);
    g_PBQueue = NULL;

    sl_Stop(SL_STOP_TIMEOUT);
    UART_PRINT("\n\r Client Stop completed\r\n");

    /*Disable the SW2 and SW3 interrupt */
    //GPIO_disableInt(CONFIG_GPIO_BUTTON_0); // SW2
    //GPIO_disableInt(CONFIG_GPIO_BUTTON_1); // SW3
}

int32_t MqttClient_start()
{
    //dbgOutputLoc(MqttClient_start_START);
    int32_t lRetVal = -1;
    int32_t iCount = 0;

    int32_t threadArg = 100;
    pthread_attr_t pAttrs;
    struct sched_param priParam;

    MqttClientExmple_params.clientId = ClientId;
    MqttClientExmple_params.connParams = &Mqtt_ClientCtx;
    MqttClientExmple_params.mqttMode31 = MQTT_3_1;
    MqttClientExmple_params.blockingSend = true;

    gInitState |= CLIENT_INIT_STATE;

    /*Initialize MQTT client lib                                             */
    gMqttClient = MQTTClient_create(MqttClientCallback,
                                    &MqttClientExmple_params);
    if(gMqttClient == NULL)
    {
        /*lib initialization failed                                          */
        gInitState &= ~CLIENT_INIT_STATE;
        return(-1);
    }

    /*Open Client Receive Thread start the receive task. Set priority and    */
    /*stack size attributes                                                  */
    pthread_attr_init(&pAttrs);
    priParam.sched_priority = 2;
    lRetVal = pthread_attr_setschedparam(&pAttrs, &priParam);
    lRetVal |= pthread_attr_setstacksize(&pAttrs, RXTASKSIZE);
    lRetVal |= pthread_attr_setdetachstate(&pAttrs, PTHREAD_CREATE_DETACHED);
    lRetVal |=
        pthread_create(&g_rx_task_hndl, &pAttrs, MqttClientThread,
                       (void *) &threadArg);
    if(lRetVal != 0)
    {
        UART_PRINT("Client Thread Create Failed failed\n\r");
        gInitState &= ~CLIENT_INIT_STATE;
        return(-1);
    }
#ifdef SECURE_CLIENT
    setTime();
#endif

    /*setting will parameters                                                */
    MQTTClient_set(gMqttClient, MQTTClient_WILL_PARAM, &will_param,
                   sizeof(will_param));

#ifdef CLNT_USR_PWD
    /*Set user name for client connection                                    */
    MQTTClient_set(gMqttClient, MQTTClient_USER_NAME, (void *)ClientUsername,
                   strlen(
                       (char*)ClientUsername));

    /*Set password                                                           */
    MQTTClient_set(gMqttClient, MQTTClient_PASSWORD, (void *)ClientPassword,
                   strlen(
                       (char*)ClientPassword));
#endif
    /*Initiate MQTT Connect                                                  */
    if(gApConnectionState >= 0)
    {
#if CLEAN_SESSION == false
        bool clean = CLEAN_SESSION;
        MQTTClient_set(gMqttClient, MQTTClient_CLEAN_CONNECT, (void *)&clean,
                       sizeof(bool));
#endif
        /*The return code of MQTTClient_connect is the ConnACK value that
           returns from the server */
        lRetVal = MQTTClient_connect(gMqttClient);

        /*negative lRetVal means error,
           0 means connection successful without session stored by the server,
           greater than 0 means successful connection with session stored by
           the server */
        if(0 > lRetVal)
        {
            /*lib initialization failed                                      */
            UART_PRINT("Connection to broker failed, Error code: %d\n\r",
                       lRetVal);

            gUiConnFlag = 0;
        }
        else
        {
            gUiConnFlag = 1;
        }
        /*Subscribe to topics when session is not stored by the server       */
        if((gUiConnFlag == 1) && (0 == lRetVal))
        {
            uint8_t subIndex;
            MQTTClient_SubscribeParams subscriptionInfo[
                SUBSCRIPTION_TOPIC_COUNT];

            for(subIndex = 0; subIndex < SUBSCRIPTION_TOPIC_COUNT; subIndex++)
            {
                subscriptionInfo[subIndex].topic = topic[subIndex];
                subscriptionInfo[subIndex].qos = qos[subIndex];
            }

            if(MQTTClient_subscribe(gMqttClient, subscriptionInfo,
                                    SUBSCRIPTION_TOPIC_COUNT) < 0)
            {
                UART_PRINT("\n\r Subscription Error \n\r");
                MQTTClient_disconnect(gMqttClient);
                gUiConnFlag = 0;
            }
            else
            {
                for(iCount = 0; iCount < SUBSCRIPTION_TOPIC_COUNT; iCount++)
                {
                    UART_PRINT("Client subscribed on %s\n\r,", topic[iCount]);
                }
            }
        }
    }

    gInitState &= ~CLIENT_INIT_STATE;

    return(0);
}

//*****************************************************************************
//!
//! MQTT Client stop - Unsubscribe from the subscription topics and exit the
//! MQTT client lib.
//!
//! \param  none
//!
//! \return None
//!
//*****************************************************************************

void Mqtt_ClientStop(uint8_t disconnect)
{
    uint32_t iCount;

    MQTTClient_UnsubscribeParams subscriptionInfo[SUBSCRIPTION_TOPIC_COUNT];

    for(iCount = 0; iCount < SUBSCRIPTION_TOPIC_COUNT; iCount++)
    {
        subscriptionInfo[iCount].topic = topic[iCount];
    }

    MQTTClient_unsubscribe(gMqttClient, subscriptionInfo,
                           SUBSCRIPTION_TOPIC_COUNT);
    for(iCount = 0; iCount < SUBSCRIPTION_TOPIC_COUNT; iCount++)
    {
        UART_PRINT("Unsubscribed from the topic %s\r\n", topic[iCount]);
    }
    gUiConnFlag = 0;

    /*exiting the Client library                                             */
    MQTTClient_delete(gMqttClient);
}

//*****************************************************************************
//!
//! Utility function which prints the borders
//!
//! \param[in] ch  -  hold the charater for the border.
//! \param[in] n   -  hold the size of the border.
//!
//! \return none.
//!
//*****************************************************************************

void printBorder(char ch,
                 int n)
{
    int i = 0;

    for(i = 0; i < n; i++)
    {
        putch(ch);
    }
}

//*****************************************************************************
//!
//! Set the ClientId with its own mac address
//! This routine converts the mac address which is given
//! by an integer type variable in hexadecimal base to ASCII
//! representation, and copies it into the ClientId parameter.
//!
//! \param  macAddress  -   Points to string Hex.
//!
//! \return void.
//!
//*****************************************************************************
int32_t SetClientIdNamefromMacAddress()
{
    int32_t ret = 0;
    uint8_t Client_Mac_Name[2];
    uint8_t Index;
    uint16_t macAddressLen = SL_MAC_ADDR_LEN;
    uint8_t macAddress[SL_MAC_ADDR_LEN];

    /*Get the device Mac address */
    ret = sl_NetCfgGet(SL_NETCFG_MAC_ADDRESS_GET, 0, &macAddressLen,
                       &macAddress[0]);

    /*When ClientID isn't set, use the mac address as ClientID               */
    if(ClientId[0] == '\0')
    {
        /*6 bytes is the length of the mac address                           */
        for(Index = 0; Index < SL_MAC_ADDR_LEN; Index++)
        {
            /*Each mac address byte contains two hexadecimal characters      */
            /*Copy the 4 MSB - the most significant character                */
            Client_Mac_Name[0] = (macAddress[Index] >> 4) & 0xf;
            /*Copy the 4 LSB - the least significant character               */
            Client_Mac_Name[1] = macAddress[Index] & 0xf;

            if(Client_Mac_Name[0] > 9)
            {
                /*Converts and copies from number that is greater than 9 in  */
                /*hexadecimal representation (a to f) into ascii character   */
                ClientId[2 * Index] = Client_Mac_Name[0] + 'a' - 10;
            }
            else
            {
                /*Converts and copies from number 0 - 9 in hexadecimal       */
                /*representation into ascii character                        */
                ClientId[2 * Index] = Client_Mac_Name[0] + '0';
            }
            if(Client_Mac_Name[1] > 9)
            {
                /*Converts and copies from number that is greater than 9 in  */
                /*hexadecimal representation (a to f) into ascii character   */
                ClientId[2 * Index + 1] = Client_Mac_Name[1] + 'a' - 10;
            }
            else
            {
                /*Converts and copies from number 0 - 9 in hexadecimal       */
                /*representation into ascii character                        */
                ClientId[2 * Index + 1] = Client_Mac_Name[1] + '0';
            }
        }
    }
    return(ret);
}

//*****************************************************************************
//!
//! Utility function which Display the app banner
//!
//! \param[in] appName     -  holds the application name.
//! \param[in] appVersion  -  holds the application version.
//!
//! \return none.
//!
//*****************************************************************************

int32_t DisplayAppBanner(char* appName,
                         char* appVersion)
{
    int32_t ret = 0;
    uint8_t macAddress[SL_MAC_ADDR_LEN];
    uint16_t macAddressLen = SL_MAC_ADDR_LEN;
    uint16_t ConfigSize = 0;
    uint8_t ConfigOpt = SL_DEVICE_GENERAL_VERSION;
    SlDeviceVersion_t ver = {0};

    ConfigSize = sizeof(SlDeviceVersion_t);

    /*Print device version info. */
    ret =
        sl_DeviceGet(SL_DEVICE_GENERAL, &ConfigOpt, &ConfigSize,
                     (uint8_t*)(&ver));

    /*Print device Mac address */
    ret |= (int32_t)sl_NetCfgGet(SL_NETCFG_MAC_ADDRESS_GET, 0, &macAddressLen,
                       &macAddress[0]);

    UART_PRINT(lineBreak);
    UART_PRINT("\t");
    printBorder('=', 44);
    UART_PRINT(lineBreak);
    UART_PRINT("\t   %s Example Ver: %s",appName, appVersion);
    UART_PRINT(lineBreak);
    UART_PRINT("\t");
    printBorder('=', 44);
    UART_PRINT(lineBreak);
    UART_PRINT(lineBreak);
    UART_PRINT("\t CHIP: 0x%x",ver.ChipId);
    UART_PRINT(lineBreak);
    UART_PRINT("\t MAC:  %d.%d.%d.%d",ver.FwVersion[0],ver.FwVersion[1],
               ver.FwVersion[2],
               ver.FwVersion[3]);
    UART_PRINT(lineBreak);
    UART_PRINT("\t PHY:  %d.%d.%d.%d",ver.PhyVersion[0],ver.PhyVersion[1],
               ver.PhyVersion[2],
               ver.PhyVersion[3]);
    UART_PRINT(lineBreak);
    UART_PRINT("\t NWP:  %d.%d.%d.%d",ver.NwpVersion[0],ver.NwpVersion[1],
               ver.NwpVersion[2],
               ver.NwpVersion[3]);
    UART_PRINT(lineBreak);
    UART_PRINT("\t ROM:  %d",ver.RomVersion);
    UART_PRINT(lineBreak);
    UART_PRINT("\t HOST: %s", SL_DRIVER_VERSION);
    UART_PRINT(lineBreak);
    UART_PRINT("\t MAC address: %02x:%02x:%02x:%02x:%02x:%02x", macAddress[0],
               macAddress[1], macAddress[2], macAddress[3], macAddress[4],
               macAddress[5]);
    UART_PRINT(lineBreak);
    UART_PRINT(lineBreak);
    UART_PRINT("\t");
    printBorder('=', 44);
    UART_PRINT(lineBreak);
    UART_PRINT(lineBreak);

    return(ret);
}

void mainThread(void * args)
{
    uint32_t count = 0;
    pthread_t spawn_thread = (pthread_t) NULL;
    pthread_attr_t pAttrs_spawn;
    struct sched_param priParam;
    int32_t retc = 0;
    UART_Handle tUartHndl;

    /*Initialize SlNetSock layer with CC31xx/CC32xx interface */
    SlNetIf_init(0);
    SlNetIf_add(SLNETIF_ID_1, "CC32xx",
                (const SlNetIf_Config_t *)&SlNetIfConfigWifi,
                SLNET_IF_WIFI_PRIO);

    SlNetSock_init(0);
    SlNetUtil_init(0);

    GPIO_init();
    SPI_init();
    //DebugGPIO_init();

    /*Configure the UART                                                     */
    tUartHndl = InitTerm();
    /*remove uart receive from LPDS dependency                               */
    UART_control(tUartHndl, UART_CMD_RXDISABLE, NULL);


    /*Create the sl_Task                                                     */
    pthread_attr_init(&pAttrs_spawn);
    priParam.sched_priority = SPAWN_TASK_PRIORITY;
    retc = pthread_attr_setschedparam(&pAttrs_spawn, &priParam);
    retc |= pthread_attr_setstacksize(&pAttrs_spawn, TASKSTACKSIZE);
    retc |= pthread_attr_setdetachstate
                                    (&pAttrs_spawn, PTHREAD_CREATE_DETACHED);

    retc = pthread_create(&spawn_thread, &pAttrs_spawn, sl_Task, NULL);

    if(retc != 0)
    {
        UART_PRINT("could not create simplelink task\n\r");
        while(1)
        {
            ;
        }
    }

    retc = sl_Start(0, 0, 0);
    if(retc < 0)
    {
        /*Handle Error */
        UART_PRINT("\n sl_Start failed\n");
        while(1)
        {
            ;
        }
    }

    /*Output device information to the UART terminal */
    retc = DisplayAppBanner(APPLICATION_NAME, APPLICATION_VERSION);
    /*Set the ClientId with its own mac address */
    retc |= SetClientIdNamefromMacAddress();


    retc = sl_Stop(SL_STOP_TIMEOUT);
    if(retc < 0)
    {
        /*Handle Error */
        UART_PRINT("\n sl_Stop failed\n");
        while(1)
        {
            ;
        }
    }

    if(retc < 0)
    {
        /*Handle Error */
        UART_PRINT("mqtt_client - Unable to retrieve device information \n");
        while(1)
        {
            ;
        }
    }
    //dbgOutputLoc(DBG_mainThread_BEFOREWHILE);
    while(1)
    {
        gResetApplication = false;
        topic[0] = SUBSCRIPTION_TOPIC0;
        topic[1] = SUBSCRIPTION_TOPIC1;
        topic[2] = SUBSCRIPTION_TOPIC2;
        topic[3] = SUBSCRIPTION_TOPIC3;
        gInitState = 0;

        /*Connect to AP                                                      */
        gApConnectionState = Mqtt_IF_Connect();

        gInitState |= MQTT_INIT_STATE;
        /*Run MQTT Main Thread (it will open the Client and Server)          */
        Mqtt_start();

        /*Wait for init to be completed!!!                                   */
        while(gInitState != 0)
        {
            UART_PRINT(".");
            sleep(1);
        }
        UART_PRINT(".\r\n");

        while(gResetApplication == false)
        {
            ;
        }

        UART_PRINT("TO Complete - Closing all threads and resources\r\n");

        /*Stop the MQTT Process                                              */
        Mqtt_Stop();

        //UART_PRINT("reopen MQTT # %d  \r\n", ++count);
        //dbgOutputLoc(DBG_mainThread_DISCONNECTED);
        while(true)
        {
            ;
        }
    }
}

//*****************************************************************************
//
// Close the Doxygen group.
//! @}
//
//*****************************************************************************
