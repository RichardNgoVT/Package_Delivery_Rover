/*
 * Motor_Control.c
 *
 *  Created on: Feb 21, 2020
 *      Author: richa
 */
#include "Motor_Control.h"



void Init_Motor(){
        //UART_init();

        UART_Params uartParams;
        UART_Params_init(&uartParams);

        uartParams.writeMode = UART_MODE_BLOCKING;
        uartParams.readMode = UART_MODE_BLOCKING;
        uartParams.writeDataMode = UART_DATA_BINARY;
        uartParams.readDataMode = UART_DATA_BINARY;
        uartParams.baudRate = 9600;
        uartParams.readEcho = UART_ECHO_OFF;
        uartParams.readReturnMode = UART_RETURN_FULL;

        uart = UART_open(motor_control, &uartParams);

        if (uart == NULL){
            while(1);
        }

        //uint8_t baudset = 170;
        //sleep(2);
        //UART_write(uart, &baudset, sizeof(baudset));
}


void Set_Motors(int32_t power[]){
    int i;
    int converter;
    int reverse;
    uint8_t speed;

    for(i = 0; i<3; i++){
        converter = abs(power[i]);
        reverse = 0;
        if(power[i]<0){
            reverse = 1;
        }

        if(converter>127){
            converter = 127;
        }

        if(converter<0){
            converter = 0;
        }

        speed = converter;

        Drive_Motor(i+1,reverse,speed);
    }

}

void Drive_Motor(uint8_t motor, uint8_t direction, int8_t speed){


    uint8_t address = 128+motor;

    uint8_t checksum = (address+direction+speed)&0b01111111;

    //uint32_t command = (address << 8) + direction;
    //command = (command << 8) + speed;
    //command = (command << 8) + checksum;

    //UART_write(uart, &command, sizeof(command));
    UART_write(uart, &address, sizeof(address));
    UART_write(uart, &direction, sizeof(direction));
    UART_write(uart, &speed, sizeof(speed));
    UART_write(uart, &checksum, sizeof(checksum));

}


