/*
 * SPI_Handle.c
 *
 *  Created on: Feb 21, 2020
 *      Author: richa
 */


#include "SPI_Handle.h"

void SPI_Callback(SPI_Handle spi, SPI_Transaction *tran){
    if (tran->status == SPI_STATUS_SUCCESS) {
        if(tran->count > 4){
            read_count+=1;
            GPIO_write(read_count, 1);

            if(read_count==3){
                read_count=0;

                msg m;
                int32_t result;
                result = (motorRx1[1] << 8) + motorRx1[2];
                result = (result << 8) + motorRx1[3];
                result = (result << 8) + motorRx1[4];
                m.data[0] = result;

                result = (motorRx2[1] << 8) + motorRx2[2];
                result = (result << 8) + motorRx2[3];
                result = (result << 8) + motorRx2[4];
                m.data[1] = result;

                result = (motorRx3[1] << 8) + motorRx3[2];
                result = (result << 8) + motorRx3[3];
                result = (result << 8) + motorRx3[4];
                m.data[2] = result;

                m.here = true;
                sendToEncoderQueue(m);
            }
            else{
                Read_SPI(read_count+1, SPI_read_ctr);
            }
        }
        else
        {
            set_count+=1;
            GPIO_write(set_count, 1);
            if(set_count==3){
                set_count=0;
            }
            else{
                Set_SPI(set_count+1, SPI_setTo_Empty);
            }
        }
    }

}

void Init_Encoder(){
    Init_GPIOs();
    Init_SPI();
}

void Init_GPIOs() {
    GPIO_init();
    GPIO_setConfig(slaveSel_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(slaveSel_2, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(slaveSel_3, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(motor_exitFail, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_write(slaveSel_1, 1);
    GPIO_write(slaveSel_2, 1);
    GPIO_write(slaveSel_3, 1);
    GPIO_write(motor_exitFail, 1);
}

void Init_SPI(){
    SPI_init();

    SPI_Params spiParams;

    SPI_init();  // Initialize the SPI driver

    SPI_Params_init(&spiParams);  // Initialize SPI parameters
    spiParams.dataSize = 8;       // 8-bit data size
    spiParams.transferMode = SPI_MODE_CALLBACK;
    spiParams.transferCallbackFxn = SPI_Callback;
    spi = SPI_open(motor_data, &spiParams);
    while (spi == NULL) {

    }
    set_count = 0;
    read_count = 0;
    Set_SPI(1, SPI_setTo_Empty);
}

void Set_SPI(uint_least8_t slave, uint8_t command){
    GPIO_write(slave,0);
    if(slave == 1){
        setTx1[0] = command;
        memset((void *) setRx1, 0, 1);
        transaction1.count = 1;
        transaction1.txBuf = (void *) setTx1;
        transaction1.rxBuf = (void *) setRx1;

        /* Perform SPI transfer */
        SPI_transfer(spi, &transaction1);
    }
    else if(slave == 2){
        setTx2[0] = command;
        memset((void *) setRx2, 0, 1);
        transaction2.count = 1;
        transaction2.txBuf = (void *) setTx2;
        transaction2.rxBuf = (void *) setRx2;

        /* Perform SPI transfer */
        SPI_transfer(spi, &transaction2);
    }
    else if(slave == 3){
        setTx3[0] = command;
        memset((void *) setRx3, 0, 1);
        transaction3.count = 1;
        transaction3.txBuf = (void *) setTx3;
        transaction3.rxBuf = (void *) setRx3;
        /* Perform SPI transfer */

        SPI_transfer(spi, &transaction3);
    }
}

void Read_SPI(uint_least8_t slave, uint8_t command){
    GPIO_write(slave,0);

    if(slave == 1){
        motorTx1[0] = command;
        memset((void *) motorRx1, 0, 5);
        transaction1.count = 5;
        transaction1.txBuf = (void *) motorTx1;
        transaction1.rxBuf = (void *) motorRx1;

        /* Perform SPI transfer */
        SPI_transfer(spi, &transaction1);
    }
    else if(slave == 2){
        motorTx2[0] = command;
        memset((void *) motorRx2, 0, 5);
        transaction2.count = 5;
        transaction2.txBuf = (void *) motorTx2;
        transaction2.rxBuf = (void *) motorRx2;

    /* Perform SPI transfer */

    SPI_transfer(spi, &transaction2);
    }
    else if(slave == 3){
        motorTx3[0] = command;
        memset((void *) motorRx3, 0, 5);
        transaction3.count = 5;
        transaction3.txBuf = (void *) motorTx3;
        transaction3.rxBuf = (void *) motorRx3;

    /* Perform SPI transfer */

    SPI_transfer(spi, &transaction3);
    }
}





