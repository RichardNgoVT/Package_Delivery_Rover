#ifndef SENSOR_QUEUE_H_
#define SENSOR_QUEUE_H_

#include <FreeRTOS.h>
#include <queue.h>
#include <stdbool.h>
//#include "json_parse.h"


#define QUEUE_LEN       4
//#define QUEUE_ITEM_SIZE 8
#define ZERO            0

typedef struct msg {
    bool here;
    bool set;
    int32_t data[3];
 } msg;

 typedef struct dev_data {

     char* id;   // Name of topic ('ultra', 'pixy', 'rover', 'arm', 'statistics', or 'topics')
     int pub;    // Number of published messages
     int rec;    // Number of recieved messages

     int time;
     int dist;  // distance
     int x;     // x-coordinate
     int y;     // y-coordinate
     int height;
     int width;
     int signature;
     char* status;  // true or false
     char* atDestination;

     //motordata
     int travel[3];
     int speed[3];

     int mode;

     double ki[3];
     double kp[3];



     // topics

 } dev_data;



QueueHandle_t encoder;
QueueHandle_t command;
QueueHandle_t input;
QueueHandle_t MqttR;

void MQ_init();


bool sendToMQTTQueue(dev_data m);

dev_data readFromMQTTQueue();


void message_init(msg *msg);

bool sendToEncoderQueue(msg m);

msg readFromEncoderQueue();

bool sendToCommandQueue(msg m);

msg readFromCommandQueue();

//bool sendToInputQueue(msg m);

//msg readFromInputQueue();

#endif /* SENSOR_QUEUE_H_ */
