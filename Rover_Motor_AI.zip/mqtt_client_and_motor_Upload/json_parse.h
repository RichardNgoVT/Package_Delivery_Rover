#include "cJSON.h"
#include "uart_term.h"
#include "Msg_Queue.h"


/* Prints out struct values to UART */
void printDevData(dev_data d);

/* Wrapper for cJSON_GetObjectItemCaseSensitive function*/
int getIntValue(cJSON *obj, char *field);

char *getStrValue(cJSON *obj, char *field);

/* Returns a struct with values from str string (JSON format) */
struct dev_data getJSONData(char *str);
