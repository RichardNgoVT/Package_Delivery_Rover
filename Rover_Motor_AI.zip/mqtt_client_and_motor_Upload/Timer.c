/*
 * timertwo.c
 *
 *  Created on: Feb 5, 2020
 *      Author: Brandon
 */

#include "Timer.h"
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/Timer.h>
void Init_ReadTimer()
{


    Timer_Params params2;
    Timer_Params_init(&params2);

    params2.period = TIMER_PERIOD;
    params2.periodUnits = Timer_PERIOD_US;
    params2.timerMode = Timer_CONTINUOUS_CALLBACK;
    params2.timerCallback = ReadTimer_Callback;
    UART_PRINT("timer:before\n\r");
    TimerSample = Timer_open(read_timer, &params2);
    UART_PRINT("timer:after\n\r");
    if (TimerSample == NULL)
    {
        UART_PRINT("timer:null\n\r");
        while(1);
        //dbgHaltAll(DLOC_TIMETWO_FAILED_INIT);
    }

    if (Timer_start(TimerSample) == Timer_STATUS_ERROR)
    {
        UART_PRINT("timer:error\n\r");
        while(1);
        //dbgHaltAll(DLOC_TIMERTWO_FAILED_START);
    }
    passedTime = 0;

}


void ReadTimer_Callback(Timer_Handle myHandle)
{
    passedTime+=1;
    Read_SPI(slaveSel_1, SPI_read_ctr);
}

bool ReadTimer_Check(int32_t checkTime){
    if(passedTime>=checkTime){
        passedTime = 0;
        return true;
    }
    else{
        return false;
    }
}
