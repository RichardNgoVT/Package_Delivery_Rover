#include "Msg_Queue.h"

// testing 1 2 3

void message_init(msg *msg)
{
    (*msg).here = false;
    (*msg).data[0] = 0;
    (*msg).data[1] = 0;
    (*msg).data[2] = 0;
}

void MQ_init()
{
    encoder = xQueueCreate(QUEUE_LEN, sizeof(msg));
    command = xQueueCreate(QUEUE_LEN, sizeof(msg));
    input = xQueueCreate(QUEUE_LEN, sizeof(msg));
    MqttR = xQueueCreate(QUEUE_LEN, sizeof(dev_data));
}


bool sendToMQTTQueue(dev_data m)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    BaseType_t result = xQueueSendToBackFromISR(MqttR,
                                                &m, &xHigherPriorityTaskWoken);
    bool success =  (pdPASS == result);
    if(!success)
    {
        while(1);
        //dbgHaltAll(DLOC_QUEUE_SEND_FAIL);
    }

    return true;
}

dev_data readFromMQTTQueue()
{
    dev_data m;


    xQueueReceive(MqttR, &m, portMAX_DELAY);

    return m;
}


bool sendToEncoderQueue(msg m)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    BaseType_t result = xQueueSendToBackFromISR(encoder,
                                                &m, &xHigherPriorityTaskWoken);
    bool success =  (pdPASS == result);
    if(!success)
    {
        while(1);
        //dbgHaltAll(DLOC_QUEUE_SEND_FAIL);
    }

    return true;
}

msg readFromEncoderQueue()
{
    msg m = {
              .here=false,
              .data[0] = 0,
              .data[1] = 0,
              .data[2] = 0,
        };


    xQueueReceive(encoder, &m, portMAX_DELAY);

    return m;
}

bool sendToCommandQueue(msg m)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    BaseType_t result = xQueueSendToBackFromISR(command,
                                                &m, &xHigherPriorityTaskWoken);
    bool success =  (pdPASS == result);
    if(!success)
    {
        while(1);
        //dbgHaltAll(DLOC_QUEUE_SEND_FAIL);
    }

    return true;
}

msg readFromCommandQueue()
{
    msg m = {
              .here=false,
              .data[0] = 0,
              .data[1] = 0,
              .data[2] = 0,
        };


    xQueueReceive(command, &m, portMAX_DELAY);

    return m;
}

/*bool sendToInputQueue(msg m)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    BaseType_t result = xQueueSendToBackFromISR(input,
                                                &m, &xHigherPriorityTaskWoken);
    bool success =  (pdPASS == result);
    if(!success)
    {
        while(1);
        //dbgHaltAll(DLOC_QUEUE_SEND_FAIL);
    }

    return true;
}

msg readFromInputQueue()
{
    msg m = {
              .here=false,
              .data[0] = 0,
              .data[1] = 0,
              .data[2] = 0,
        };


    xQueueReceive(input, &m, portMAX_DELAY);

    return m;
}*/




