/*
 * Motor_Control.c
 *
 *  Created on: Feb 21, 2020
 *      Author: richa
 */
#include "Motor_CalcPower.h"

void Init_PID(){
    int i;
    for(i=0;i<3;i++){
            Kp[i] = 0.05;//127/65
            Ki[i] = 0.05;//1/15
            goal[i] = 0;
            curOut[i] = 0;
            ErrSum[i] = 0;
            pastDist[i] = 0;
            pastSpeed[i] = 1;
        }

    Kp[0] = 0.47;
    Kp[1] = 0.3;
    Kp[2] = 0.4;

    Ki[0] = 1.83;
    Ki[1] = 1.86;
    Ki[2] = 1.85;
    debounce = true;
}

void setGoals_PID(int32_t goal1, int32_t goal2, int32_t goal3){
    if(pastGoal[0] != goal1 || pastGoal[1] != goal2 || pastGoal[2] != goal3){
        goal[0] = goal1;
        goal[1] = goal2;
        goal[2] = goal3;

        pastGoal[0] = goal1;
        pastGoal[1] = goal2;
        pastGoal[2] = goal3;


    pastSpeed[0] = 1;
    pastSpeed[1] = 1;
    pastSpeed[2] = 1;
    //UART_PRINT("NewGoals: %d, %d, %d", goal1,goal2, goal3);
    }

    //char uartOut[50];
    //sprintf(uartOut,"G1: %d  G2: %d  G3: %d   ", goal1, goal2, goal3);
    //dbgUARTStr(uartOut);
}

void setKp_PID(double Kp1, double Kp2, double Kp3){
    Kp[0] = Kp1;
    Kp[1] = Kp2;
    Kp[2] = Kp3;
}


void setKi_PID(double Ki1, double Ki2, double Ki3){
    Ki[0] = Ki1;
    Ki[1] = Ki2;
    Ki[2] = Ki3;
}



void update_Motors(int32_t curDist[]){
    int i;
    int32_t speeds[3];
    int Err;

    char uartOut[50];

    dev_data msg_Data;
    msg msg_Command;

    msg_Data.id = "motors";
    msg_Command.here = true;

    bool send_Data = true;
    bool send_Command = true;
    int checker;

    for(i = 0; i <3; i++){
        speeds[i] = curDist[i]-pastDist[i];


        //if(pastDist[i] != curDist[i]){
            pastDist[i] = curDist[i];
       //     send_Data = true;
        //}
        Err = goal[i]-speeds[i];

        ErrSum[i] = Err+ErrSum[i];
        /*
        checker = curOut[i]+Err*Kp[i]+ErrSum[i]*Ki[i];
        if(curOut[i] != checker){
            curOut[i] = checker;
            send_Command = true;
        }

        msg_Command.data[i] = curOut[i];

        */
        if(goal[i] == 0){
            msg_Command.data[i] = 0;
            ErrSum[i] = 0;
        }
        else{
        msg_Command.data[i] = Err*Kp[i]+ErrSum[i]*Ki[i];
        }
        //sprintf(uartOut,"M%d: %d  ", i+1, speeds[i]);

        //dbgUARTStr(uartOut);

        msg_Data.travel[i] = curDist[i];
        msg_Data.speed[i] = speeds[i];
        if(pastSpeed[i] != 0 || speeds[i] != 0){
            send_Data = true;

        }
        pastSpeed[i] = speeds[i];
    }
    //dbgUARTStr(" ");
    //sprintf(uartOut,"M%d: %f  M%d: %f  M%d: %f  \r\n", 1, msg_Command.data[0], 2, msg_Command.data[1], 3, msg_Command.data[2]);
    //UART_PRINT("M1: %d  M2: %d  M3: %d  \r\n", speeds[0], speeds[1], speeds[2]);
    //dbgUARTStr(uartOut);


    if(send_Command){

        sendToCommandQueue(msg_Command);
    }
    if(send_Data || debounce){
        sendToMQTTQueue(msg_Data);
    }

    //debounce = send_Data;
    debounce = false;




}





