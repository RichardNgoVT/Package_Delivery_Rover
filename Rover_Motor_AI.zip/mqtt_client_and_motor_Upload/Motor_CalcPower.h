/*
 * Motor_Control.h
 *
 *  Created on: Feb 21, 2020
 *      Author: richa
 */

#ifndef EMBEDDED_SYSTEMS_COMMAND_MOTORS_H_
#define EMBEDDED_SYSTEMS_COMMAND_MOTORS_H_
#include <stdint.h>
#include "debug.h"
#include "Msg_Queue.h"

double Kp[3];
double Ki[3];
int32_t goal[3];
int32_t curOut[3];
int32_t pastDist[3];
int32_t pastSpeed[3];
int32_t pastGoal[3];
double ErrSum[3];
bool debounce;

void Init_PID();
void setGoals_PID(int32_t goal1, int32_t goal2, int32_t goal3);
void setKp_PID(double Kp1, double Kp2, double Kp3);
void setKi_PID(double Ki1, double Ki2, double Ki3);
void update_Motors(int32_t speeds[]);

#endif /* EMBEDDED_SYSTEMS_COMMAND_MOTORS_H_ */
