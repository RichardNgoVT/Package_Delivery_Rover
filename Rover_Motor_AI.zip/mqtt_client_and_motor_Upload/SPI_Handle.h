/*
 * SPI_Handle.h
 *
 *  Created on: Feb 21, 2020
 *      Author: richa
 */

#ifndef EMBEDDED_SYSTEMS_SPI_HANDLE_H_
#define EMBEDDED_SYSTEMS_SPI_HANDLE_H_

#include <stddef.h>
#include <stdint.h>
#include <string.h>

#include <ti/drivers/GPIO.h>
#include <ti/drivers/SPI.h>
#include "ti_drivers_config.h"
#include "Msg_Queue.h"


#define SPI_read_ctr        0b01100000
#define SPI_read_otr        0b01101000
#define SPI_setTo_MDR0      0b10001000
#define SPI_setTo_MDR1      0b10010000
#define SPI_setTo_4bytes    0b00000000
#define SPI_setTo_4Quad     0b00000011
#define SPI_setTo_Empty     0b00100000

SPI_Handle      spi;

uint8_t setTx1[1];
uint8_t setTx2[1];
uint8_t setTx3[1];

uint8_t setRx1[1];
uint8_t setRx2[1];
uint8_t setRx3[1];

uint8_t motorTx1[5];
uint8_t motorTx2[5];
uint8_t motorTx3[5];

uint8_t motorRx1[5];
uint8_t motorRx2[5];
uint8_t motorRx3[5];

SPI_Transaction transaction1;
SPI_Transaction transaction2;
SPI_Transaction transaction3;

uint8_t read_count;
uint8_t set_count;


void Init_Encoder();

void Init_GPIOs();

void Init_SPI();

void Read_SPI(uint_least8_t slave, uint8_t command);

void Set_SPI(uint_least8_t slave, uint8_t command);

void SPI_Callback(SPI_Handle spi, SPI_Transaction *tran);

#endif /* EMBEDDED_SYSTEMS_SPI_HANDLE_H_ */
